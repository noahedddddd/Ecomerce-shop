import Button from '@components/common/Button';
import '@components/frontStore/cms/Button.scss';

export default Button;
export { Button };
