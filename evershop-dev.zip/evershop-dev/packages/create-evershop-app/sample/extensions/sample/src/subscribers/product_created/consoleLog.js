export default function consoleLog(data) {
  console.log('Product Created:', data);
}
